# aos-session
JSON Session

# localhost

1. Run cmd from terminal:
	sudo npm install -g live-server
2. Go to your folder then run below cmd:
	live-server

	(OR)
	
1. Run cmd from terminal:
	npm install http-server -g
2. Go to your folder then run below cmd:
	http-server
